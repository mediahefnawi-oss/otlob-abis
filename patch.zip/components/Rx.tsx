import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Image, AppState, Pressable, Modal } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { C } from '../lib/theme';
import { T, Card, Btn, Icon, Sheet, Field, Chip, toast, confirmDialog } from './ui';
import { useStore, useMe } from '../lib/store';
import { storage } from '../lib/storage';
import { navigationRef } from '../lib/nav';
import { Appointment } from '../lib/types';
import { RxRow, apiRxList, apiRxPharmacies, apiRxCreate, apiRxPhoto, apiRxStep } from '../lib/api';
import { pickImage, canPickImage } from '../lib/pickImage';

const STATUS: Record<string, { label: string; color: string }> = {
  issued: { label: 'بانتظار اختيارك للصيدلية', color: C.goldDeep }, sent: { label: 'وصلت الصيدلية', color: C.goldDeep }, ready: { label: 'جاهزة للاستلام ✅', color: C.green },
  picked_up: { label: 'تم الاستلام', color: C.sub }, delivery: { label: 'طلبت توصيل', color: C.goldDeep }, cancelled: { label: 'ملغية', color: C.red }, expired: { label: 'انتهت صلاحيتها', color: C.red },
};
// lets any prescription card re-open the full sheet (RxAutoOpen registers itself here); it is also the way back after "لاحقًا"
let openRxHandler: ((id: string) => void) | null = null;
export const openRx = (id: string) => { if (openRxHandler) openRxHandler(id); };
const priceOf = (r: RxRow) => (r.price ? `${r.price} ج` : '');
const left = (r: RxRow) => { const d = Math.ceil((r.expiresAt - Date.now()) / 86400000); return d > 0 ? `باقي ${d} يوم` : ''; };

function usePoll<T2>(f: () => Promise<T2>, on: boolean) {
  const [v, setV] = useState<T2 | null>(null);
  const load = useCallback(() => { f().then(setV).catch(() => {}); }, [f]);
  useEffect(() => { if (!on) return; load(); const t = setInterval(load, 20000); return () => clearInterval(t); }, [load, on]);
  return [v, load] as const;
}

function RxPhoto({ id }: { id: string }) {
  const [img, setImg] = useState<string | null>(null);
  useEffect(() => { apiRxPhoto(id).then((r) => setImg(r.image)).catch(() => {}); }, [id]);
  const [big, setBig] = useState(false);
  if (!img) return null;
  // tap the picture to see it full size (the pharmacy has to read the doctor's handwriting)
  return (
    <>
      <Pressable onPress={() => setBig(true)}>
        <Image source={{ uri: img }} style={{ width: '100%', height: 190, borderRadius: 14, backgroundColor: C.line }} resizeMode="contain" />
        <T size={11} color={C.sub} align="center">اضغط على الصورة لتكبيرها 🔍</T>
      </Pressable>
      <Modal visible={big} transparent animationType="fade" onRequestClose={() => setBig(false)}>
        <Pressable onPress={() => setBig(false)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.92)', justifyContent: 'center', padding: 12 }}>
          <Image source={{ uri: img }} style={{ width: '100%', height: '85%' }} resizeMode="contain" />
          <T w="bold" size={13} color="#fff" align="center" style={{ marginTop: 10 }}>اضغط في أي مكان للإغلاق ✕</T>
        </Pressable>
      </Modal>
    </>
  );
}

/** Clinic: write the prescription for a confirmed booking and suggest a pharmacy (the patient's own area first). */
export function ClinicRxButton({ a }: { a: Appointment }) {
  const { db } = useStore();
  const [open, setOpen] = useState(false);
  if (!db.settings.features?.rx || a.lab || !['confirmed', 'completed'].includes(a.status)) return null;
  return (
    <>
      <Btn small variant="soft" icon="medkit" title="اكتب روشتة 💊" onPress={() => setOpen(true)} />
      <ClinicRxSheet a={a} visible={open} onClose={() => setOpen(false)} />
    </>
  );
}

/** The prescription sheet. The clinic's screen opens it by itself right after "تمت الزيارة" so the doctor never has to look for it. */
export function ClinicRxSheet({ a, visible, onClose }: { a: Appointment; visible: boolean; onClose: () => void }) {
  const [meds, setMeds] = useState('');
  const [img, setImg] = useState<string | null>(null);
  const [phs, setPhs] = useState<{ id: string; name: string; region: string; suggested: boolean }[]>([]);
  const [ph, setPh] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!visible) return;
    setMeds(''); setImg(null); setPh('');
    apiRxPharmacies(a.id).then((r) => { setPhs(r.pharmacies); const s = r.pharmacies.find((x) => x.suggested); if (s) setPh(s.id); }).catch(() => {});
  }, [visible, a.id]);
  const pick = async () => {
    if (!canPickImage) return toast('رفع الصور متاح حاليًا من نسخة الويب', 'info');
    const x = await pickImage(1100);
    if (x) setImg(x); else toast('تعذر تحميل الصورة', 'err');
  };
  const send = async () => {
    if (!meds.trim() && !img) return toast('اكتب الأدوية أو ارفع صورة الروشتة', 'err');
    setBusy(true);
    try { const r = await apiRxCreate({ appointmentId: a.id, meds, image: img, pharmacyId: ph || undefined }); onClose(); toast(`تم إرسال الروشتة ${r.rx.number} للمريض ✅ وهيوصله إشعار`); }
    catch (e: any) { toast(e?.message || 'تعذر الإرسال', 'err'); }
    finally { setBusy(false); }
  };
  return (
    <>
      <Sheet visible={visible} onClose={onClose} title={`روشتة للمريض ${a.patientName || ''}`}>
        <Field label="الأدوية والجرعات" icon="create" value={meds} onChangeText={setMeds} multiline placeholder="مثال: أموكسيسيلين 500 مرتين يوميًا لمدة 5 أيام" />
        {img ? <Image source={{ uri: img }} style={{ width: '100%', height: 140, borderRadius: 14 }} resizeMode="contain" /> : null}
        <Btn variant="soft" icon="camera" title={img ? 'تغيير الصورة' : 'أو ارفع صورة الروشتة'} onPress={pick} />
        {!!phs.length && <T w="bold" size={12.5}>اقترح صيدلية (⭐ الأقرب لمنطقة المريض)</T>}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {phs.map((p) => <Chip key={p.id} label={`${p.suggested ? '⭐ ' : ''}${p.name}${p.region ? ` • ${p.region}` : ''}`} active={ph === p.id} onPress={() => setPh(ph === p.id ? '' : p.id)} />)}
        </View>
        <T size={11.5} color={C.sub}>المريض هو اللي يوافق على الصيدلية أو يغيّرها، ومفيش صيدلية بتشوف الروشتة قبل موافقته. صلاحيتها 7 أيام.</T>
        <Btn title="إرسال الروشتة للمريض" icon="send" loading={busy} onPress={send} />
        <Btn variant="soft" title="مفيش روشتة دلوقتي" onPress={onClose} />
      </Sheet>
    </>
  );
}

/** Patient: his prescriptions. Approve / change the pharmacy, collect it or ask for delivery. */
export function MyRxCard() {
  const { db } = useStore();
  const nav: any = useNavigation();
  const on = !!db.settings.features?.rx;
  const [v, load] = usePoll(apiRxList, on);
  const [choice, setChoice] = useState<{ rx: string; ph: string } | null>(null);
  if (!on || !v || !v.list.length) return null;
  const pharmacies = db.providers.filter((p) => p.type === 'pharmacy' && p.status === 'active');
  const act = async (id: string, step: any, body?: any) => {
    try {
      const r = await apiRxStep(id, step, body);
      load();
      if (step === 'delivery' && r.orderText && r.pharmacyId) nav.navigate('RequestOrder', { id: r.pharmacyId, prefill: r.orderText });
      else toast('تم ✅');
    } catch (e: any) { toast(e?.message || 'تعذر التنفيذ', 'err'); }
  };
  return (
    <View style={{ gap: 10 }}>
      <T w="black" size={15}>💊 روشتاتي</T>
      {v.list.filter((r) => r.role === 'patient').map((r) => {
        const st = STATUS[r.status] || STATUS.issued;
        return (
          <Card key={r.id} style={{ gap: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <T w="black" size={15} style={{ flex: 1 }}>{r.number}</T>
              <T w="bold" size={12} color={st.color}>{st.label}</T>
            </View>
            <T size={12} color={C.sub}>من {r.clinicName}{r.pharmacyName ? ` • ${r.pharmacyName}` : ''} {left(r) ? `• ${left(r)}` : ''}</T>
            {!!r.meds && <T size={13}>{r.meds}</T>}
            {r.hasImage && <RxPhoto id={r.id} />}
            {!!r.price && <T w="black" size={14} color={C.green}>سعر الأدوية: {priceOf(r)}</T>}
            {r.needsAction && <Btn small icon="open" title="فتح الروشتة" onPress={() => openRx(r.id)} />}
            {r.status === 'issued' && (
              <View style={{ gap: 8 }}>
                <T w="bold" size={12.5}>اختار الصيدلية اللي تستلم منها</T>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {pharmacies.map((p) => <Chip key={p.id} label={`${p.id === r.pharmacyId ? '⭐ ' : ''}${p.name}`} active={choice?.rx === r.id && choice.ph === p.id} onPress={() => setChoice({ rx: r.id, ph: p.id })} />)}
                </View>
                <Btn small icon="checkmark" title={r.pharmacyId && choice?.rx !== r.id ? `موافق على ${r.pharmacyName}` : 'تأكيد الصيدلية'} onPress={() => act(r.id, 'choose', { pharmacyId: choice?.rx === r.id ? choice.ph : r.pharmacyId || undefined })} />
              </View>
            )}
            {r.status === 'ready' && (
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Btn small variant="green" icon="checkmark-done" title="استلمتها" style={{ flex: 1 }} onPress={() => act(r.id, 'pickup')} />
                <Btn small variant="soft" icon="bicycle" title="وصّلها لي (+ رسوم التوصيل)" style={{ flex: 1 }} onPress={() => act(r.id, 'delivery')} />
              </View>
            )}
            {r.status === 'sent' && <Btn small variant="soft" icon="bicycle" title="وصّلها لي" onPress={() => act(r.id, 'delivery')} />}
            {['issued', 'sent'].includes(r.status) && <Btn small variant="danger" icon="close" title="إلغاء الروشتة" onPress={() => confirmDialog({ title: 'إلغاء الروشتة؟', danger: true, confirmText: 'إلغاء', onConfirm: () => act(r.id, 'cancel') })} />}
          </Card>
        );
      })}
    </View>
  );
}

/** Pharmacy: prescriptions the patients chose to send here. */
export function PharmacyRxInbox({ compact }: { compact?: boolean } = {}) {
  const { db } = useStore();
  const on = !!db.settings.features?.rx;
  const [v, load] = usePoll(apiRxList, on);
  const [prices, setPrices] = useState<Record<string, string>>({}); // all hooks come before any early return
  if (!on) return null;
  const mine = (v?.list || []).filter((r) => r.role === 'pharmacy' && (!compact || ['sent', 'ready', 'delivery'].includes(r.status)));
  if (compact && !mine.length) return null;
  const act = async (id: string, step: any, body?: any) => { try { await apiRxStep(id, step, body); load(); toast('تم ✅'); } catch (e: any) { toast(e?.message || 'تعذر التنفيذ', 'err'); } };
  const needPrice = (id: string) => { const n = Number((prices[id] || '').replace(',', '.')); if (!(n > 0)) { toast('اكتب سعر الأدوية الأول', 'err'); return null; } return n; };
  return (
    <Card style={{ gap: 10 }}>
      <T w="black" size={15}>💊 {compact ? `روشتات للتجهيز (${mine.length})` : 'الروشتات'}</T>
      {!mine.length && !compact && <T size={12.5} color={C.sub}>لا توجد روشتات بعد.</T>}
      {mine.map((r) => {
        const st = STATUS[r.status] || STATUS.sent;
        return (
          <View key={r.id} style={{ gap: 6, paddingTop: 8, borderTopWidth: 1, borderTopColor: C.line }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <T w="black" size={14.5} style={{ flex: 1 }}>{r.number} • {r.patientName}</T>
              <T w="bold" size={12} color={st.color}>{st.label}</T>
            </View>
            <T w="bold" size={12.5} color={C.goldDeep}>🩺 محوّلة من {r.clinicName}</T>
            <Btn small variant="soft" icon="open" title="فتح الروشتة" onPress={() => openRx(r.id)} />
            {!!r.meds && <T size={13}>{r.meds}</T>}
            {r.hasImage && <RxPhoto id={r.id} />}
            {['sent', 'ready'].includes(r.status) && (
              <Field label={r.status === 'sent' ? 'سعر الأدوية (جنيه)' : `سعر الأدوية الحالي ${priceOf(r)} — تعديل`} icon="cash" value={prices[r.id] ?? (r.price ? String(r.price) : '')} onChangeText={(v) => setPrices({ ...prices, [r.id]: v })} keyboardType="decimal-pad" placeholder="مثال: 185" />
            )}
            {r.status === 'sent' && <Btn small variant="green" icon="checkmark" title="جاهزة للاستلام" onPress={() => { const n = needPrice(r.id); if (n) act(r.id, 'ready', { price: n }); }} />}
            {r.status === 'ready' && <Btn small variant="soft" icon="cash" title="حفظ السعر الجديد" onPress={() => { const n = needPrice(r.id); if (n) act(r.id, 'price', { price: n }); }} />}
            {['sent', 'ready', 'delivery'].includes(r.status) && <Btn small variant="soft" icon="checkmark-done" title="تم التسليم" onPress={() => act(r.id, 'pickup')} />}
          </View>
        );
      })}
    </Card>
  );
}

/**
 * Opens the prescription by itself for whoever has to act now, while the app is open: the patient (confirm the pharmacy, then "collect it or deliver
 * it?") and the pharmacy (a new prescription to prepare). Each step is shown once (remembered on the phone); the sound notification brings people
 * to the app, and this sheet is the first thing they see.
 */
export function RxAutoOpen() {
  const { db } = useStore();
  const me = useMe();
  const on = !!db.settings.features?.rx && !!me && me.status === 'active' && (me.role === 'customer' || me.role === 'provider');
  const role = me?.role === 'customer' ? 'patient' : 'pharmacy';
  const [cur, setCur] = useState<RxRow | null>(null);
  const [choice, setChoice] = useState('');
  const [price, setPrice] = useState('');
  const [busy, setBusy] = useState(false);
  const curRef = useRef<RxRow | null>(null);
  const seen = useRef<Set<string>>(new Set());
  const seenReady = useRef<Promise<void> | null>(null);
  const key = (r: RxRow) => `${r.id}:${r.status}`;
  if (!seenReady.current) {
    seenReady.current = storage.getItem('rx_seen').then((v) => { try { (JSON.parse(v || '[]') as string[]).forEach((k) => seen.current.add(k)); } catch { /* ignore */ } }).catch(() => {});
  }
  const check = useCallback(async () => {
    if (!on || curRef.current) return;
    try {
      await seenReady.current;
      const v = await apiRxList();
      const next = v.list.find((x) => x.needsAction && x.role === role && !seen.current.has(key(x)));
      if (next && !curRef.current) { curRef.current = next; setChoice(next.pharmacyId || ''); setPrice(next.price ? String(next.price) : ''); setCur(next); }
    } catch { /* the next poll tries again */ }
  }, [on, role]);
  useEffect(() => {
    if (!on) return;
    check();
    const t = setInterval(check, 15000);
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') check(); });
    return () => { clearInterval(t); sub.remove(); };
  }, [on, check]);
  useEffect(() => {
    openRxHandler = async (id: string) => {
      try {
        const x = (await apiRxList()).list.find((q) => q.id === id);
        if (x && !curRef.current) { curRef.current = x; setChoice(x.pharmacyId || ''); setPrice(x.price ? String(x.price) : ''); setCur(x); }
      } catch { toast('تعذر فتح الروشتة', 'err'); }
    };
    return () => { openRxHandler = null; };
  }, []);
  const close = (r: RxRow) => {
    seen.current.add(key(r));
    storage.setItem('rx_seen', JSON.stringify([...seen.current].slice(-100))).catch(() => {});
    curRef.current = null; setCur(null);
    setTimeout(check, 400);
  };
  const act = async (r: RxRow, step: any, body?: any, done?: string) => {
    setBusy(true);
    try {
      const x = await apiRxStep(r.id, step, body);
      close(r);
      if (step === 'delivery' && x.orderText && x.pharmacyId && navigationRef.isReady()) (navigationRef as any).navigate('RequestOrder', { id: x.pharmacyId, prefill: x.orderText });
      else if (done) toast(done);
    } catch (e: any) { toast(e?.message || 'تعذر التنفيذ', 'err'); }
    finally { setBusy(false); }
  };
  if (!on || !cur) return null;
  const pharmacies = db.providers.filter((p) => p.type === 'pharmacy' && p.status === 'active');
  const r = cur;
  return (
    <Sheet visible onClose={() => close(r)} title={r.role === 'patient' ? (r.status === 'ready' ? `💊 روشتتك جاهزة في ${r.pharmacyName}` : `💊 روشتة جديدة من ${r.clinicName}`) : '💊 روشتة جديدة للتجهيز'}>
      <T size={12.5} color={C.sub}>{r.number}{r.role === 'pharmacy' ? ` • ${r.patientName}` : ''} {left(r) ? `• ${left(r)}` : ''}</T>
      {r.role === 'pharmacy' && <T w="bold" size={13} color={C.goldDeep}>🩺 محوّلة من {r.clinicName}</T>}
      {!!r.meds && <Card style={{ padding: 12 }}><T size={14}>{r.meds}</T></Card>}
      {r.hasImage && <RxPhoto id={r.id} />}
      {r.role === 'patient' && r.status === 'issued' && (
        <View style={{ gap: 10 }}>
          <T w="bold" size={13}>{r.pharmacyId ? `العيادة رشّحت لك ${r.pharmacyName}` : 'اختار الصيدلية اللي تستلم منها'}</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {pharmacies.map((p) => <Chip key={p.id} label={`${p.id === r.pharmacyId ? '⭐ ' : ''}${p.name}`} active={choice === p.id} onPress={() => setChoice(p.id)} />)}
          </View>
          <Btn icon="checkmark" title={choice && choice === r.pharmacyId ? `موافق على ${r.pharmacyName}` : 'تأكيد الصيدلية'} loading={busy} onPress={() => (choice ? act(r, 'choose', { pharmacyId: choice }, 'اتبعتت للصيدلية، هيوصلك إشعار لما تجهز ✅') : toast('اختار صيدلية', 'err'))} />
          <Btn variant="soft" title="لاحقًا" onPress={() => close(r)} />
        </View>
      )}
      {r.role === 'patient' && r.status === 'ready' && (
        <View style={{ gap: 10 }}>
          {!!r.price && <Card style={{ padding: 12 }}><T w="black" size={15} color={C.green}>سعر الأدوية: {priceOf(r)}</T></Card>}
          <T w="bold" size={13}>تحب تستلمها بنفسك ولا نوصّلهالك؟ (التوصيل بيزيد رسوم توصيل منطقتك وبتظهر في الفاتورة)</T>
          <Btn variant="green" icon="walk" title="هعدّي أستلمها" loading={busy} onPress={() => { close(r); toast('تمام، الصيدلية مستنياك ✅'); }} />
          <Btn icon="bicycle" title="وصّلها لي" loading={busy} onPress={() => act(r, 'delivery')} />
          <Btn variant="soft" title="لاحقًا" onPress={() => close(r)} />
        </View>
      )}
      {r.role === 'patient' && !['issued', 'ready'].includes(r.status) && <Btn variant="soft" title="إغلاق" onPress={() => close(r)} />}
      {r.role === 'pharmacy' && r.status !== 'sent' && <Btn variant="soft" title="إغلاق" onPress={() => close(r)} />}
      {r.role === 'pharmacy' && r.status === 'sent' && (
        <View style={{ gap: 10 }}>
          <Field label="سعر الأدوية (جنيه)" icon="cash" value={price} onChangeText={setPrice} keyboardType="decimal-pad" placeholder="مثال: 185" />
          <Btn variant="green" icon="checkmark" title="جاهزة للاستلام (هنبلّغ العميل)" loading={busy} onPress={() => { const n = Number(price.replace(',', '.')); if (!(n > 0)) return toast('اكتب سعر الأدوية الأول', 'err'); act(r, 'ready', { price: n }, 'اتبلّغ العميل ✅'); }} />
          <Btn variant="soft" title="لاحقًا" onPress={() => close(r)} />
        </View>
      )}
    </Sheet>
  );
}
