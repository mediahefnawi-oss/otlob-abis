import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { apiPushConfig, apiPushRegister, apiPushUnregister, apiPushTest } from './api';

/**
 * Alerts that work while the app is closed.
 *  - phone app: Expo push token (needs the `expo-notifications` package and an EAS build);
 *  - browser / installed web app: Web Push through /sw.js (needs the server's VAPID keys).
 * The server repeats a shop's alert until the shop accepts the order.
 */
declare const require: any;

const isWeb = Platform.OS === 'web' && typeof window !== 'undefined';
export type PushResult = 'on' | 'denied' | 'unsupported' | 'off' | 'error';

let nativeToken: string | null = null;
let nativeReady = false;

/* ---------- web ---------- */
const webSupported = () => isWeb && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
const b64ToBytes = (b64: string) => {
  const pad = '='.repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
};

/** What the browser can do right now, without asking the user anything. */
export async function webPushState(): Promise<PushResult> {
  if (!isWeb) return 'unsupported';
  if (!webSupported()) return 'unsupported';
  if (Notification.permission === 'denied') return 'denied';
  if (Notification.permission !== 'granted') return 'off';
  try {
    const reg = await navigator.serviceWorker.getRegistration('/');
    return reg && (await reg.pushManager.getSubscription()) ? 'on' : 'off';
  } catch { return 'off'; }
}

/** Makes the page installable (helps iPhone, where browser alerts work only for an installed web app). */
export function preparePwa() {
  if (!isWeb || typeof document === 'undefined') return;
  const add = (tag: string, attrs: Record<string, string>) => {
    const sel = Object.entries(attrs).filter(([k]) => k === 'rel' || k === 'name').map(([k, v]) => `[${k}="${v}"]`).join('');
    if (document.head.querySelector(`${tag}${sel}`)) return;
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
    document.head.appendChild(el);
  };
  add('link', { rel: 'manifest', href: '/manifest.json' });
  add('link', { rel: 'apple-touch-icon', href: '/icons/icon-192.png' });
  add('meta', { name: 'apple-mobile-web-app-capable', content: 'yes' });
  add('meta', { name: 'theme-color', content: '#00211A' });
}

async function registerWeb(ask: boolean): Promise<PushResult> {
  if (!webSupported()) return 'unsupported';
  if (Notification.permission === 'denied') return 'denied';
  if (Notification.permission === 'default') {
    if (!ask) return 'off';
    const p = await Notification.requestPermission();
    if (p === 'denied') return 'denied';
    if (p !== 'granted') return 'off';
  }
  const { webPublicKey } = await apiPushConfig();
  if (!webPublicKey) return 'unsupported'; // the server has no VAPID keys yet
  await navigator.serviceWorker.register('/sw.js');
  const reg = await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(webPublicKey) as any });
  await apiPushRegister({ kind: 'web', subscription: sub.toJSON() });
  return 'on';
}

/* ---------- phone ---------- */
function native(): any | null {
  try { return require('expo-notifications'); } catch { return null; }
}

async function registerNative(): Promise<PushResult> {
  const N = native();
  if (!N) return 'unsupported';
  if (!nativeReady) {
    N.setNotificationHandler({
      handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
    } as any);
    if (Platform.OS === 'android') {
      await N.setNotificationChannelAsync('orders', {
        name: 'الطلبات الجديدة',
        importance: N.AndroidImportance.MAX,
        sound: 'new_order.wav',
        vibrationPattern: [0, 400, 200, 400, 200, 400],
        enableVibrate: true,
        lockscreenVisibility: N.AndroidNotificationVisibility.PUBLIC,
      });
    }
    nativeReady = true;
  }
  let perm = await N.getPermissionsAsync();
  if (perm.status !== 'granted') perm = await N.requestPermissionsAsync();
  if (perm.status !== 'granted') return 'denied';
  const projectId = (Constants as any)?.expoConfig?.extra?.eas?.projectId || (Constants as any)?.easConfig?.projectId;
  const t = await N.getExpoPushTokenAsync(projectId ? { projectId } : undefined);
  nativeToken = String(t.data);
  await apiPushRegister({ kind: 'expo', token: nativeToken });
  return 'on';
}

/** Registers this device for alerts. `ask` lets the browser show its permission question (call it from a tap). */
export async function registerPush(ask = false): Promise<PushResult> {
  try { return isWeb ? await registerWeb(ask) : await registerNative(); }
  catch { return 'error'; }
}

/** Stops alerts for the signed-in account on this device (call while the session token still exists). */
export async function unregisterPush(): Promise<void> {
  try {
    if (isWeb) {
      if (!webSupported()) return;
      const reg = await navigator.serviceWorker.getRegistration('/');
      const sub = reg ? await reg.pushManager.getSubscription() : null;
      if (sub) { await apiPushUnregister(sub.endpoint).catch(() => {}); await sub.unsubscribe().catch(() => {}); }
    } else if (nativeToken) {
      await apiPushUnregister(nativeToken).catch(() => {});
      nativeToken = null;
    }
  } catch {}
}

/** Sends a test alert to this account's devices; returns a message for the user. */
export async function testPush(): Promise<{ ok: boolean; message: string }> {
  try {
    const r = await apiPushTest();
    return { ok: true, message: `تم إرسال تنبيه تجريبي إلى ${r.devices} جهاز` };
  } catch (e: any) {
    return { ok: false, message: e?.message || 'تعذر إرسال التنبيه التجريبي' };
  }
}
