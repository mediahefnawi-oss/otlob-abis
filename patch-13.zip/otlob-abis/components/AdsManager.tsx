import React, { useCallback, useEffect, useState } from 'react';
import { View, Image, Pressable } from 'react-native';
import { C } from '../lib/theme';
import { T, Icon, Card, Btn, Field, Toggle, toast, confirmDialog } from './ui';
import {
  ApiError, ServerAd, apiAdminListAds, apiAdminCreateAd, apiAdminUpdateAd, apiAdminDeleteAd, apiUrl,
} from '../lib/api';
import { pickImage, canPickImage } from '../lib/pickImage';
import { syncRemote } from '../lib/store';

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'حدث خطأ غير متوقع. حاول مرة أخرى');

/** Owner: add picture ads (they appear on every customer's home screen), switch them off, delete them. */
export function AdsManager() {
  const [ads, setAds] = useState<ServerAd[] | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [link, setLink] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try { setAds((await apiAdminListAds()).ads); } catch (e) { toast(msg(e), 'err'); setAds((a) => a || []); }
  }, []);
  useEffect(() => { load(); }, [load]);
  const refreshHome = () => { syncRemote(true).catch(() => {}); };

  const choose = async () => {
    const img = await pickImage({ maxSide: 1400, maxChars: 850000 });
    if (!img) return toast('تعذّر قراءة الصورة. جرّب صورة أخرى', 'err');
    setImage(img);
  };
  const publish = async () => {
    if (!image) return toast('اختر صورة الإعلان أولاً', 'err');
    setBusy(true);
    try {
      await apiAdminCreateAd({ image, title: title.trim(), linkUrl: link.trim() });
      setImage(null); setTitle(''); setLink('');
      await load(); refreshHome();
      toast('تم نشر الإعلان ويظهر الآن للعملاء 📢');
    } catch (e) { toast(msg(e), 'err'); }
    setBusy(false);
  };
  const toggle = async (a: ServerAd, v: boolean) => {
    try { await apiAdminUpdateAd(a.id, { active: v }); await load(); refreshHome(); } catch (e) { toast(msg(e), 'err'); }
  };
  const remove = (a: ServerAd) => confirmDialog({
    title: 'حذف الإعلان؟', message: 'سيختفي من شاشة العملاء نهائياً.', danger: true, confirmText: 'حذف',
    onConfirm: async () => { try { await apiAdminDeleteAd(a.id); await load(); refreshHome(); toast('تم حذف الإعلان'); } catch (e) { toast(msg(e), 'err'); } },
  });

  return (
    <Card style={{ gap: 12 }}>
      <T w="black" size={15}>اللوحة الإعلانية ({ads ? ads.length : '…'})</T>
      <T size={11.5} color={C.sub}>صور الإعلانات تظهر أعلى الصفحة الرئيسية عند العملاء وتتبدّل تلقائياً. الأفضل صورة عريضة بنسبة 16:7.</T>

      {(ads || []).map((a) => (
        <View key={a.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: C.line }}>
          <Image source={{ uri: apiUrl(a.imageUrl) }} style={{ width: 96, height: 42, borderRadius: 8, backgroundColor: C.line, opacity: a.active ? 1 : 0.4 }} resizeMode="cover" />
          <View style={{ flex: 1 }}>
            <T w="bold" size={13} numberOfLines={1} color={a.active ? C.text : C.sub}>{a.title || 'بدون عنوان'}</T>
            <T size={11} color={C.sub} numberOfLines={1}>{a.linkUrl || 'بدون رابط'}{a.active ? '' : ' • متوقف'}</T>
          </View>
          <Toggle value={a.active} onValueChange={(v) => toggle(a, v)} />
          <Pressable hitSlop={8} onPress={() => remove(a)}><Icon name="trash" size={19} color={C.red} /></Pressable>
        </View>
      ))}
      {ads && ads.length === 0 && <T size={12.5} color={C.sub}>لا توجد إعلانات بعد.</T>}

      <View style={{ gap: 10, paddingTop: 12, borderTopWidth: 1, borderTopColor: C.line }}>
        <T w="bold" size={13.5}>إعلان جديد</T>
        {canPickImage ? (
          <>
            <Pressable onPress={choose} style={{ borderWidth: 1.5, borderStyle: 'dashed', borderColor: C.line, borderRadius: 14, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', minHeight: 90 }}>
              {image
                ? <Image source={{ uri: image }} style={{ width: '100%', aspectRatio: 16 / 7 }} resizeMode="cover" />
                : <View style={{ alignItems: 'center', gap: 4, padding: 16 }}><Icon name="image" size={24} color={C.goldDeep} /><T size={12.5} color={C.sub}>اضغط لاختيار صورة الإعلان</T></View>}
            </Pressable>
            <Field label="عنوان يظهر على الصورة (اختياري)" value={title} onChangeText={setTitle} icon="text" />
            <Field label="رابط عند الضغط على الإعلان (اختياري)" value={link} onChangeText={setLink} icon="link" autoCapitalize="none" />
            <Btn title="نشر الإعلان" icon="megaphone" onPress={publish} disabled={busy || !image} />
          </>
        ) : (
          <T size={12} color={C.sub}>رفع صور جديدة متاح حالياً من نسخة الويب (افتح التطبيق من المتصفح بحساب المالك). يمكنك هنا إيقاف الإعلانات أو حذفها.</T>
        )}
      </View>
    </Card>
  );
}
