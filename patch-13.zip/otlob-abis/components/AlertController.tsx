import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { useStore, useMe, needsShopAck, needsClinicAnswer } from '../lib/store';
import { setRinging } from '../lib/alerts';
import { registerPush, preparePwa } from '../lib/push';

/**
 * Invisible. For shops and couriers:
 *  - registers this device for alerts that work while the app is closed;
 *  - while a shop has an order it has not accepted, keeps the sound ringing (web; phones get the repeating push).
 */
export function AlertController() {
  const { db } = useStore();
  const me = useMe();
  const works = !!me && me.status === 'active' && (me.role === 'provider' || me.role === 'courier');

  const waiting = me && me.role === 'provider' && me.status === 'active'
    ? db.orders.filter((o) => o.providerOwnerId === me.id && needsShopAck(o)).length
      + db.appointments.filter((a) => a.clinicOwnerId === me.id && needsClinicAnswer(a)).length
    : 0;
  const ringing = waiting > 0;

  useEffect(() => { setRinging(ringing); return () => setRinging(false); }, [ringing]);

  useEffect(() => {
    if (Platform.OS === 'web') preparePwa();
  }, []);

  useEffect(() => {
    if (works) registerPush(false); // the browser asks for permission only from a tap (see SoundGate); phones ask here
  }, [works, me?.id]);

  return null;
}
