import React, { useEffect, useState } from 'react';
import { Pressable } from 'react-native';
import { C } from '../lib/theme';
import { T, Icon, toast } from './ui';
import { useMe } from '../lib/store';
import { soundReady, soundSupported, subscribeSound, enableSound, playNewOrderSound } from '../lib/alerts';
import { PushResult, registerPush, webPushState } from '../lib/push';

/**
 * Shops and couriers on the web: browsers keep the page silent until it is tapped once, and show alerts while the
 * app is closed only after the user allows notifications. This bar asks for that one tap and does both.
 */
export function SoundGate() {
  const me = useMe();
  const [ready, setReady] = useState(soundReady());
  const [push, setPush] = useState<PushResult>('on');
  useEffect(() => subscribeSound(() => setReady(soundReady())), []);
  useEffect(() => { webPushState().then(setPush); }, [me?.id, ready]);

  const needs = !ready || push === 'off';
  if (!me || !['provider', 'courier'].includes(me.role) || !soundSupported() || !needs) return null;

  const onPress = async () => {
    const ok = await enableSound();
    if (ok) playNewOrderSound();
    const r = await registerPush(true);
    setPush(r === 'error' ? 'off' : r);
    if (r === 'on') toast('تم تفعيل التنبيهات 🔔 ستصلك الطلبات حتى والتطبيق مغلق');
    else if (r === 'denied') toast('التنبيهات محظورة في المتصفح. فعّلها من إعدادات الموقع ثم أعد المحاولة', 'err');
    else if (r === 'unsupported') toast(ok ? 'تم تفعيل الصوت. تنبيهات الخلفية غير متاحة هنا (على الآيفون أضف التطبيق للشاشة الرئيسية وافتحه منها)' : 'تعذر تفعيل الصوت', ok ? 'ok' : 'err');
    else if (r === 'error') toast('تعذر تفعيل تنبيهات الخلفية الآن، حاول مرة أخرى', 'err');
    else if (ok) toast('تم تفعيل صوت تنبيه الطلبات 🔔');
  };

  return (
    <Pressable onPress={onPress} style={{ backgroundColor: C.gold, paddingVertical: 10, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      <Icon name="notifications" size={18} color={C.dark} />
      <T w="bold" size={13} color={C.dark} style={{ flex: 1 }}>
        {!ready ? 'اضغط هنا لتفعيل تنبيه الطلبات (صوت + حتى والتطبيق مغلق)' : 'اضغط هنا لتفعيل التنبيه حتى والتطبيق مغلق'}
      </T>
    </Pressable>
  );
}
