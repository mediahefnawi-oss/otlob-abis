import React, { useState } from 'react';
import { View } from 'react-native';
import { C } from '../lib/theme';
import { T, Icon, Card, Btn, toast } from './ui';
import { registerPush, testPush } from '../lib/push';

/** Lets a shop or courier check that alerts reach this device while the app is closed. */
export function PushTestCard() {
  const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true);
    const r = await registerPush(true);
    if (r === 'denied') { setBusy(false); return toast('التنبيهات محظورة. فعّلها من إعدادات الجهاز أو المتصفح ثم جرّب مجدداً', 'err'); }
    if (r === 'unsupported') { setBusy(false); return toast('هذا الجهاز لا يدعم تنبيهات الخلفية (على الآيفون أضف التطبيق للشاشة الرئيسية وافتحه منها)', 'err'); }
    const t = await testPush();
    setBusy(false);
    toast(t.message, t.ok ? 'ok' : 'err');
  };
  return (
    <Card style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Icon name="notifications" size={22} color={C.goldDeep} />
        <View style={{ flex: 1 }}>
          <T w="bold" size={14}>تنبيهات الطلبات</T>
          <T size={12} color={C.sub}>ترن حتى والتطبيق مغلق، وتتكرر لحين قبول الطلب.</T>
        </View>
      </View>
      <Btn small variant="soft" icon="notifications" title="تجربة التنبيه الآن" onPress={run} disabled={busy} />
    </Card>
  );
}
