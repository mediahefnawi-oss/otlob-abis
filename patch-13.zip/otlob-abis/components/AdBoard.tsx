import React, { useEffect, useRef, useState } from 'react';
import { View, Image, Pressable, Animated, Linking, Platform } from 'react-native';
import { C } from '../lib/theme';
import { T } from './ui';
import { Ad } from '../lib/types';
import { apiUrl } from '../lib/api';

/** The advertising board on the home screen: picture ads from the owner, changing every few seconds. */
export function AdBoard({ ads }: { ads: Ad[] }) {
  const list = ads.filter((a) => a.active);
  const n = list.length;
  const [i, setI] = useState(0);
  const fade = useRef(new Animated.Value(1)).current;

  useEffect(() => { if (i >= n) setI(0); }, [n]);
  useEffect(() => {
    if (n < 2) return;
    const t = setInterval(() => setI((x) => (x + 1) % n), 5000);
    return () => clearInterval(t); // restarts after a manual change, so a tapped dot is not skipped at once
  }, [n, i]);
  useEffect(() => {
    fade.setValue(0.25);
    Animated.timing(fade, { toValue: 1, duration: 350, useNativeDriver: Platform.OS !== 'web' }).start();
  }, [i]);

  if (!n) return null;
  const ad = list[Math.min(i, n - 1)];
  const open = () => { if (ad.linkUrl) Linking.openURL(ad.linkUrl).catch(() => {}); };

  return (
    <View style={{ marginBottom: 14, gap: 8 }}>
      <Pressable onPress={open} disabled={!ad.linkUrl} style={{ borderRadius: 18, overflow: 'hidden', backgroundColor: C.line, aspectRatio: 16 / 7 }}>
        <Animated.View style={{ flex: 1, opacity: fade }}>
          <Image source={{ uri: apiUrl(ad.imageUrl) }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
          {!!ad.title && (
            <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,33,26,0.62)', paddingHorizontal: 12, paddingVertical: 6 }}>
              <T w="bold" size={12.5} color="#fff" numberOfLines={1}>{ad.title}</T>
            </View>
          )}
        </Animated.View>
      </Pressable>
      {n > 1 && (
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
          {list.map((a, k) => (
            <Pressable key={a.id} hitSlop={8} onPress={() => setI(k)}>
              <View style={{ width: k === i ? 18 : 7, height: 7, borderRadius: 4, backgroundColor: k === i ? C.gold : C.line }} />
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}
