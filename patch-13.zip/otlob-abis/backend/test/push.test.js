'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const createPush = require('../src/push');
const createAds = require('../src/ads');

function fakePool(handlers) {
  const log = [];
  return {
    log,
    async query(sql, params) {
      log.push({ sql: sql.replace(/\s+/g, ' ').trim(), params });
      for (const [re, rows] of handlers) if (re.test(sql)) return { rows: typeof rows === 'function' ? rows(params) : rows, rowCount: 1 };
      return { rows: [], rowCount: 0 };
    },
  };
}
function stubFetch(responder) {
  const calls = [];
  global.fetch = async (url, opts) => { const body = JSON.parse(opts.body); calls.push({ url, body }); return { json: async () => (responder ? responder(body) : { data: body.map(() => ({ status: 'ok' })) }) }; };
  return calls;
}
const owner = [/FROM providers WHERE id/, [{ id: 5, owner_user_id: 9 }]];
const token = [/FROM push_tokens WHERE user_id/, [{ id: 1, user_id: 9, kind: 'expo', token: 'ExponentPushToken[abc]', subscription: null }]];

test('a new order sends one phone alert to the shop owner with the order sound and channel', async () => {
  const calls = stubFetch();
  const pool = fakePool([[/UPDATE orders SET last_alert_at/, [{ id: 1, provider_id: 5, order_number: 101, total: '90.00', data: { customerName: 'أحمد' }, alert_count: 1 }]], owner, token]);
  await createPush({ pool })._internal.notifyOrder(1);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://exp.host/--/api/v2/push/send');
  const m = calls[0].body[0];
  assert.equal(m.to, 'ExponentPushToken[abc]');
  assert.match(m.title, /^🔔 طلب جديد #101$/);
  assert.match(m.body, /أحمد — 90 ج\.م/);
  assert.equal(m.channelId, 'orders');
  assert.equal(m.sound, 'new_order.wav');
  assert.equal(m.priority, 'high');
});

test('a repeat alert is marked as a reminder', async () => {
  const calls = stubFetch();
  const pool = fakePool([[/UPDATE orders SET last_alert_at/, [{ id: 1, provider_id: 5, order_number: 101, total: '90', data: { customerName: 'أحمد' }, alert_count: 4 }]], owner, token]);
  await createPush({ pool })._internal.notifyOrder(1);
  assert.match(calls[0].body[0].title, /^⏰ تذكير: /);
});

test('several waiting orders of one shop become ONE alert, not one per order', async () => {
  const calls = stubFetch();
  const rows = [1, 2, 3].map(n => ({ id: n, provider_id: 5, order_number: 100 + n, total: '50', data: { customerName: 'x' }, alert_count: 2 }));
  const pool = fakePool([owner, token]);
  await createPush({ pool })._internal.alertProviders(rows, []);
  assert.equal(calls.length, 1);
  assert.match(calls[0].body[0].title, /3 طلبات/);
});

test('a written request asks the shop to price it, and a booking says so', async () => {
  const calls = stubFetch();
  const pool = fakePool([owner, token]);
  const P = createPush({ pool })._internal;
  await P.alertProviders([{ id: 1, provider_id: 5, order_number: 7, total: '0', data: { customerName: 'سلمى', request: { text: 'x' } }, alert_count: 1 }], []);
  assert.match(calls[0].body[0].body, /بانتظار تسعيرك/);
  await P.alertProviders([], [{ id: 12, provider_id: 5, appointment_time: '5:00 م', date_str: '2026-11-02', data: { patientName: 'منى' }, alert_count: 1 }]);
  assert.match(calls[1].body[0].title, /حجز جديد #512/);
});

test('a device the push service no longer knows is removed', async () => {
  stubFetch(() => ({ data: [{ status: 'error', details: { error: 'DeviceNotRegistered' } }] }));
  const pool = fakePool([[/UPDATE orders SET last_alert_at/, [{ id: 1, provider_id: 5, order_number: 1, total: '1', data: {}, alert_count: 1 }]], owner, token]);
  await createPush({ pool })._internal.notifyOrder(1);
  assert.ok(pool.log.some(q => /DELETE FROM push_tokens WHERE id = ANY/.test(q.sql) && q.params[0][0] === 1));
});

test('nothing is sent when no order is due (already accepted or alerted a moment ago)', async () => {
  const calls = stubFetch();
  const pool = fakePool([owner, token]); // the UPDATE returns no rows
  await createPush({ pool })._internal.notifyOrder(1);
  assert.equal(calls.length, 0);
});

test('the alert query only picks orders the shop has not accepted, with a cadence and a time limit', async () => {
  stubFetch();
  const pool = fakePool([]);
  await createPush({ pool })._internal.notifyOrder(1);
  const q = pool.log.find(x => /UPDATE orders SET last_alert_at/.test(x.sql)).sql;
  assert.match(q, /provider_ack_at IS NULL/);
  assert.match(q, /status IN \('pending','accepted'\)/);
  assert.match(q, /INTERVAL '40 seconds'/);
  assert.match(q, /INTERVAL '120 minutes'/);
  assert.match(q, /FOR UPDATE SKIP LOCKED/);
});

test('couriers: an auto-assigned order alerts only that courier; an open one alerts every available courier', async () => {
  const calls = stubFetch();
  const base = { order_number: 55, data: { regionName: 'التحرير', providerName: 'مطعم' } };
  let pool = fakePool([[/FROM orders WHERE id=\$1 AND status/, [{ ...base, courier_user_id: 31 }]], [/FROM push_tokens/, [{ id: 3, user_id: 31, kind: 'expo', token: 'ExponentPushToken[c1]' }]]]);
  await createPush({ pool })._internal.notifyCouriers(1);
  assert.match(calls[0].body[0].title, /تم تعيين طلب لك #55/);
  pool = fakePool([[/FROM orders WHERE id=\$1 AND status/, [{ ...base, courier_user_id: null }]], [/role='courier'/, [{ id: 31 }, { id: 32 }]],
    [/FROM push_tokens/, [{ id: 3, user_id: 31, kind: 'expo', token: 'ExponentPushToken[c1]' }, { id: 4, user_id: 32, kind: 'expo', token: 'ExponentPushToken[c2]' }]]]);
  await createPush({ pool })._internal.notifyCouriers(1);
  assert.equal(calls[1].body.length, 2);
});

test('ads: the public list carries a versioned image address and never the picture itself', async () => {
  const when = new Date('2026-10-28T10:00:00Z');
  const pool = fakePool([[/FROM ads WHERE active/, [{ id: 4, title: 'خصم', link_url: 'https://x.example', active: true, sort_order: 1, updated_at: when }]]]);
  const list = await createAds({ pool }).listPublic();
  assert.deepEqual(list, [{ id: '4', title: 'خصم', linkUrl: 'https://x.example', active: true, sortOrder: 1, imageUrl: `/api/ads/4/image?v=${when.getTime()}` }]);
});

test('ads: a broken ads table never takes the catalog down', async () => {
  const pool = { async query() { throw new Error('relation "ads" does not exist'); } };
  const origErr = console.error; console.error = () => {};
  const list = await createAds({ pool }).listPublic();
  console.error = origErr;
  assert.deepEqual(list, []);
});
