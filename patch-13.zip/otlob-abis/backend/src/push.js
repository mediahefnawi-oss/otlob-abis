'use strict';
/**
 * Push alerts that work while the app is closed.
 *  - phones (APK/IPA): Expo push service, token registered by the app;
 *  - browsers / installed web app: Web Push (VAPID) through the optional `web-push` package.
 * A shop (or clinic) is re-alerted every ~40 seconds (every 5 minutes after the first 15) until it accepts the order /
 * answers the booking, for at most MAX_WINDOW_MIN minutes. Couriers get one alert per new delivery.
 */
let webpush = null;
try { webpush = require('web-push'); } catch { /* optional: browser alerts stay off until `npm install` brings it */ }

module.exports = function createPush({ pool }) {
  const EXPO_URL = 'https://exp.host/--/api/v2/push/send';
  const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY || '';
  const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || '';
  const MAX_WINDOW_MIN = 120;
  let webReady = !!(webpush && VAPID_PUBLIC && VAPID_PRIVATE);
  if (webReady) {
    try { webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', VAPID_PUBLIC, VAPID_PRIVATE); }
    catch (e) { console.error('Browser push disabled:', e.message); webReady = false; }
  } else {
    console.log(`Browser push is off (${webpush ? 'VAPID keys missing' : 'web-push package not installed'}). Phone push works with Expo tokens.`);
  }

  let armed = true; // the repeater only touches the database while something may be waiting (keeps a sleeping database asleep)
  const arm = () => { armed = true; };
  const money = n => `${Number(n) || 0} ج.م`;

  /* ---------- sending ---------- */
  const tokensFor = async ids => ids.length
    ? (await pool.query('SELECT id, user_id, kind, token, subscription FROM push_tokens WHERE user_id = ANY($1::bigint[])', [ids])).rows : [];
  const dropTokens = async ids => { if (ids.length) await pool.query('DELETE FROM push_tokens WHERE id = ANY($1::bigint[])', [ids]).catch(() => {}); };

  async function sendExpo(rows, msg) {
    const dead = [];
    for (let i = 0; i < rows.length; i += 100) {
      const chunk = rows.slice(i, i + 100);
      const body = chunk.map(t => ({ to: t.token, title: msg.title, body: msg.body, sound: 'new_order.wav', channelId: 'orders', priority: 'high', ttl: 120, data: msg.data || {} }));
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 10000);
      try {
        const res = await fetch(EXPO_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body), signal: ctl.signal });
        const json = await res.json().catch(() => ({}));
        (json.data || []).forEach((t, k) => { if (t && t.status === 'error' && t.details && t.details.error === 'DeviceNotRegistered') dead.push(chunk[k].id); });
      } catch (e) { console.error('Expo push failed:', e.message); } finally { clearTimeout(timer); }
    }
    await dropTokens(dead);
  }
  async function sendWeb(rows, msg) {
    if (!webReady) return;
    const dead = [];
    const payload = JSON.stringify({ title: msg.title, body: msg.body, tag: msg.tag || 'otlob', url: '/', data: msg.data || {} });
    await Promise.all(rows.map(async t => {
      try { await webpush.sendNotification(t.subscription, payload, { TTL: 120, urgency: 'high' }); }
      catch (e) { if (e && (e.statusCode === 404 || e.statusCode === 410)) dead.push(t.id); else console.error('Web push failed:', (e && e.statusCode) || e.message); }
    }));
    await dropTokens(dead);
  }
  async function sendToUsers(userIds, msg) {
    const ids = [...new Set(userIds.map(Number).filter(Boolean))];
    const rows = await tokensFor(ids);
    await Promise.all([sendExpo(rows.filter(r => r.kind === 'expo'), msg), sendWeb(rows.filter(r => r.kind === 'web'), msg)]);
    return rows.length;
  }

  /* ---------- shops and clinics: alert until they answer ---------- */
  const DUE = (alias, since) => `(${alias}.last_alert_at IS NULL OR ${alias}.last_alert_at < NOW() - (CASE WHEN ${alias}.${since} > NOW() - INTERVAL '15 minutes' THEN INTERVAL '40 seconds' ELSE INTERVAL '5 minutes' END))`;

  async function claimOrders(extra = '', params = []) {
    return (await pool.query(
      `UPDATE orders SET last_alert_at = NOW(), alert_count = alert_count + 1
       WHERE id IN (
         SELECT x.id FROM orders x
         WHERE x.provider_id IS NOT NULL AND x.provider_ack_at IS NULL AND x.status IN ('pending','accepted')
           AND x.alert_since > NOW() - INTERVAL '${MAX_WINDOW_MIN} minutes' AND ${DUE('x', 'alert_since')} ${extra}
         ORDER BY x.alert_since LIMIT 100 FOR UPDATE SKIP LOCKED)
       RETURNING id, provider_id, order_number, total, data, alert_count`, params)).rows;
  }
  async function claimAppts(extra = '', params = []) {
    return (await pool.query(
      `UPDATE appointments SET last_alert_at = NOW(), alert_count = alert_count + 1
       WHERE id IN (
         SELECT x.id FROM appointments x
         WHERE x.status = 'pending' AND x.created_at > NOW() - INTERVAL '${MAX_WINDOW_MIN} minutes' AND ${DUE('x', 'created_at')} ${extra}
         ORDER BY x.created_at LIMIT 100 FOR UPDATE SKIP LOCKED)
       RETURNING id, provider_id, appointment_time, data, alert_count, to_char(appointment_date,'YYYY-MM-DD') AS date_str`, params)).rows;
  }

  async function alertProviders(orderRows, apptRows) {
    const provIds = [...new Set([...orderRows, ...apptRows].map(r => String(r.provider_id)))];
    if (!provIds.length) return;
    const owners = new Map((await pool.query('SELECT id, owner_user_id FROM providers WHERE id = ANY($1::bigint[])', [provIds])).rows.map(r => [String(r.id), r.owner_user_id]));
    const byOwner = new Map();
    const put = (pid, item) => { const o = owners.get(String(pid)); if (!o) return; if (!byOwner.has(o)) byOwner.set(o, []); byOwner.get(o).push(item); };
    orderRows.forEach(o => {
      const d = o.data || {};
      put(o.provider_id, { kind: 'order', n: o.order_number, again: o.alert_count > 1, text: d.request ? `طلب مكتوب من ${d.customerName || 'عميل'} — بانتظار تسعيرك` : `${d.customerName || 'عميل'} — ${money(o.total)}` });
    });
    apptRows.forEach(a => {
      const d = a.data || {};
      put(a.provider_id, { kind: 'appt', n: 500 + Number(a.id), again: a.alert_count > 1, text: `حجز من ${d.patientName || 'مريض'} — ${a.date_str || ''} ${a.appointment_time || ''}`.trim() });
    });
    for (const [owner, items] of byOwner) {
      const one = items.length === 1 ? items[0] : null;
      const mark = items.every(i => i.again) ? '⏰ تذكير: ' : '🔔 ';
      const title = one ? `${mark}${one.kind === 'appt' ? 'حجز جديد' : 'طلب جديد'} #${one.n}` : `${mark}${items.length} طلبات بانتظار ردّك`;
      const body = one ? `${one.text}\nافتح التطبيق واضغط «قبول» لإيقاف التنبيه` : `${items.slice(0, 4).map(i => `#${i.n}`).join('، ')} — افتح التطبيق واقبلها لإيقاف التنبيه`;
      await sendToUsers([owner], { title, body, tag: `otlob-provider-${owner}`, data: { type: 'provider_alert' } });
    }
  }

  async function notifyOrder(orderId) { arm(); await alertProviders(await claimOrders('AND x.id = $1', [orderId]), []); }
  async function notifyAppt(apptId) { arm(); await alertProviders([], await claimAppts('AND x.id = $1', [apptId])); }

  /* ---------- couriers: one alert per delivery they can take ---------- */
  async function notifyCouriers(orderId) {
    const o = (await pool.query("SELECT order_number, courier_user_id, data FROM orders WHERE id=$1 AND status IN ('accepted','ready')", [orderId])).rows[0];
    if (!o) return;
    const d = o.data || {};
    const place = d.regionName ? `منطقة ${d.regionName}` : (d.address || '');
    if (o.courier_user_id) {
      await sendToUsers([o.courier_user_id], { title: `🛵 تم تعيين طلب لك #${o.order_number}`, body: `${place} — ${d.providerName || ''}`.trim(), tag: `otlob-courier-${orderId}`, data: { type: 'courier_order' } });
      return;
    }
    const ids = (await pool.query("SELECT id FROM users WHERE role='courier' AND status='active' AND available=TRUE")).rows.map(r => r.id);
    if (ids.length) await sendToUsers(ids, { title: `🛵 طلب توصيل جديد #${o.order_number}`, body: `${place} — ${d.providerName || ''}`.trim(), tag: `otlob-courier-${orderId}`, data: { type: 'courier_order' } });
  }

  /* ---------- the repeater ---------- */
  let running = false;
  let ticks = 0;
  async function tick(isReady) {
    if (running || (isReady && !isReady())) return;
    ticks++;
    if (!armed && ticks % 30 !== 0) return; // idle: look again only every ~10 minutes (a safety net after restarts)
    running = true;
    try {
      const [o, a] = await Promise.all([claimOrders(), claimAppts()]);
      if (o.length || a.length) await alertProviders(o, a);
      else {
        const left = await pool.query(
          `SELECT (EXISTS(SELECT 1 FROM orders WHERE provider_id IS NOT NULL AND provider_ack_at IS NULL AND status IN ('pending','accepted') AND alert_since > NOW() - INTERVAL '${MAX_WINDOW_MIN} minutes')
                OR EXISTS(SELECT 1 FROM appointments WHERE status='pending' AND created_at > NOW() - INTERVAL '${MAX_WINDOW_MIN} minutes')) AS waiting`);
        if (!left.rows[0].waiting) armed = false;
      }
    } catch (e) { console.error('Alert repeater failed:', e.message); } finally { running = false; }
  }
  function start(isReady) {
    if (process.env.VERCEL) return; // serverless has no long-running process: run the API on Render/Docker for repeating alerts
    setInterval(() => tick(isReady), 20000).unref();
  }

  /* ---------- device registration ---------- */
  function registerRoutes(app, { auth, asyncRoute }) {
    app.get('/api/push/config', (_req, res) => res.json({ webPublicKey: webReady ? VAPID_PUBLIC : null }));

    app.post('/api/push/register', auth, asyncRoute(async (req, res) => {
      const b = req.body || {};
      const uid = Number(req.auth.sub);
      let token; let sub = null; let kind;
      if (b.kind === 'expo') {
        kind = 'expo'; token = String(b.token || '');
        if (!/^Expo(nent)?PushToken\[[^\]\s]+\]$/.test(token)) return res.status(400).json({ error: 'رمز التنبيه غير صالح' });
      } else if (b.kind === 'web') {
        if (!webReady) return res.status(503).json({ error: 'تنبيهات المتصفح غير مفعّلة على الخادم بعد' });
        const s = b.subscription;
        if (!s || typeof s.endpoint !== 'string' || !/^https:\/\//.test(s.endpoint) || s.endpoint.length > 1000 || !s.keys || !s.keys.p256dh || !s.keys.auth) return res.status(400).json({ error: 'اشتراك التنبيهات غير صالح' });
        kind = 'web'; token = s.endpoint; sub = { endpoint: s.endpoint, keys: { p256dh: String(s.keys.p256dh), auth: String(s.keys.auth) } };
      } else return res.status(400).json({ error: 'نوع الجهاز غير معروف' });
      await pool.query(
        `INSERT INTO push_tokens(user_id, kind, token, subscription) VALUES($1,$2,$3,$4)
         ON CONFLICT (token) DO UPDATE SET user_id=EXCLUDED.user_id, kind=EXCLUDED.kind, subscription=EXCLUDED.subscription, last_seen_at=NOW()`,
        [uid, kind, token, sub ? JSON.stringify(sub) : null]);
      await pool.query('DELETE FROM push_tokens WHERE user_id=$1 AND id NOT IN (SELECT id FROM push_tokens WHERE user_id=$1 ORDER BY last_seen_at DESC LIMIT 10)', [uid]);
      res.json({ ok: true });
    }));

    app.post('/api/push/unregister', auth, asyncRoute(async (req, res) => {
      const token = String((req.body || {}).token || '');
      if (token) await pool.query('DELETE FROM push_tokens WHERE token=$1 AND user_id=$2', [token, Number(req.auth.sub)]);
      res.json({ ok: true });
    }));

    const lastTest = new Map();
    app.post('/api/push/test', auth, asyncRoute(async (req, res) => {
      const uid = Number(req.auth.sub);
      if (Date.now() - (lastTest.get(uid) || 0) < 10000) return res.status(429).json({ error: 'انتظر ثواني ثم جرّب مرة أخرى' });
      lastTest.set(uid, Date.now());
      const n = await sendToUsers([uid], { title: '🔔 تجربة التنبيه', body: 'لو وصلك هذا الإشعار فالتنبيهات تعمل على جهازك ✅', tag: 'otlob-test', data: { type: 'test' } });
      if (!n) return res.status(409).json({ error: 'لا يوجد جهاز مسجّل لهذا الحساب. فعّل التنبيهات أولاً' });
      res.json({ ok: true, devices: n });
    }));
  }

  const safe = fn => (...a) => { Promise.resolve().then(() => fn(...a)).catch(e => console.error('push:', e.message)); };
  return { registerRoutes, start, notifyOrder: safe(notifyOrder), notifyAppt: safe(notifyAppt), notifyCouriers: safe(notifyCouriers), _internal: { notifyOrder, notifyAppt, notifyCouriers, alertProviders, tick } };
  // (the awaitable versions are exposed only so the tests can wait for them)

};
