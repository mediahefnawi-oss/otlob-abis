'use strict';
/**
 * Advertising board: the owner adds picture ads, everybody sees them on the home screen.
 * The list (small) travels with /api/catalog; each picture is a separate cacheable image URL.
 */
module.exports = function createAds({ pool }) {
  const MAX_IMAGE = 900000; // characters of base64 text (about 670 KB)
  const MAX_ADS = 20;
  const DATA_URL = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/;
  const meta = r => ({
    id: String(r.id), title: r.title || '', linkUrl: r.link_url || '', active: !!r.active, sortOrder: Number(r.sort_order) || 0,
    imageUrl: `/api/ads/${r.id}/image?v=${new Date(r.updated_at).getTime()}`,
  });
  const COLS = 'id, title, link_url, active, sort_order, updated_at';

  async function listPublic() {
    try { return (await pool.query(`SELECT ${COLS} FROM ads WHERE active=TRUE ORDER BY sort_order ASC, id DESC`)).rows.map(meta); }
    catch (e) { console.error('ads list failed:', e.message); return []; }
  }

  function cleanLink(v) {
    const s = String(v || '').trim();
    if (!s) return '';
    if (s.length > 300 || !/^https?:\/\/[^\s]+$/i.test(s)) throw Object.assign(new Error('الرابط يجب أن يبدأ بـ http:// أو https://'), { http: 400 });
    return s;
  }
  const cleanTitle = v => String(v || '').trim().slice(0, 80);

  function register(app, { auth, roles, asyncRoute, positiveId }) {
    const guard = fn => asyncRoute(async (req, res) => {
      try { await fn(req, res); } catch (e) { if (e && e.http) return res.status(e.http).json({ error: e.message }); throw e; }
    });

    app.get('/api/ads', asyncRoute(async (_req, res) => {
      res.set('Cache-Control', 'no-store');
      res.json({ ads: await listPublic() });
    }));

    // The picture itself. Public (it is an advertisement), cacheable (the URL carries a version), and allowed to load from the web app's origin.
    app.get('/api/ads/:id/image', asyncRoute(async (req, res) => {
      const id = positiveId(req.params.id);
      if (!id) return res.status(404).end();
      const r = await pool.query('SELECT image FROM ads WHERE id=$1', [id]);
      const m = r.rowCount ? DATA_URL.exec(r.rows[0].image) : null;
      if (!m) return res.status(404).end();
      res.set('Content-Type', m[1]);
      res.set('Cache-Control', 'public, max-age=604800, immutable');
      res.set('Cross-Origin-Resource-Policy', 'cross-origin');
      res.send(Buffer.from(m[2], 'base64'));
    }));

    app.get('/api/admin/ads', auth, roles('admin'), asyncRoute(async (_req, res) => {
      const r = await pool.query(`SELECT ${COLS} FROM ads ORDER BY sort_order ASC, id DESC`);
      res.json({ ads: r.rows.map(meta) });
    }));

    app.post('/api/admin/ads', auth, roles('admin'), guard(async (req, res) => {
      const b = req.body || {};
      const image = typeof b.image === 'string' ? b.image : '';
      if (!DATA_URL.test(image) || image.length > MAX_IMAGE) throw Object.assign(new Error('الصورة غير صالحة أو كبيرة جداً (الحد الأقصى نحو 650 كيلوبايت)'), { http: 400 });
      const link = cleanLink(b.linkUrl);
      const n = Number((await pool.query('SELECT COUNT(*) AS n FROM ads')).rows[0].n);
      if (n >= MAX_ADS) throw Object.assign(new Error(`الحد الأقصى ${MAX_ADS} إعلان. احذف إعلاناً قديماً أولاً`), { http: 409 });
      const next = Number((await pool.query('SELECT COALESCE(MAX(sort_order),0)+1 AS s FROM ads')).rows[0].s);
      const r = await pool.query(`INSERT INTO ads(title, link_url, image, active, sort_order) VALUES($1,$2,$3,TRUE,$4) RETURNING ${COLS}`, [cleanTitle(b.title), link, image, next]);
      res.status(201).json({ ad: meta(r.rows[0]) });
    }));

    app.patch('/api/admin/ads/:id', auth, roles('admin'), guard(async (req, res) => {
      const id = positiveId(req.params.id);
      if (!id) throw Object.assign(new Error('معرّف الإعلان غير صالح'), { http: 400 });
      const b = req.body || {};
      const cur = await pool.query(`SELECT ${COLS} FROM ads WHERE id=$1`, [id]);
      if (!cur.rowCount) throw Object.assign(new Error('الإعلان غير موجود'), { http: 404 });
      const old = cur.rows[0];
      const title = b.title === undefined ? old.title : cleanTitle(b.title);
      const link = b.linkUrl === undefined ? old.link_url : cleanLink(b.linkUrl);
      const active = b.active === undefined ? old.active : !!b.active;
      const sort = b.sortOrder === undefined ? old.sort_order : Math.max(0, Math.min(9999, Math.floor(Number(b.sortOrder)) || 0));
      const r = await pool.query(`UPDATE ads SET title=$1, link_url=$2, active=$3, sort_order=$4, updated_at=NOW() WHERE id=$5 RETURNING ${COLS}`, [title, link, active, sort, id]);
      res.json({ ad: meta(r.rows[0]) });
    }));

    app.delete('/api/admin/ads/:id', auth, roles('admin'), asyncRoute(async (req, res) => {
      const id = positiveId(req.params.id);
      if (!id) return res.status(400).json({ error: 'معرّف الإعلان غير صالح' });
      await pool.query('DELETE FROM ads WHERE id=$1', [id]);
      res.json({ ok: true });
    }));
  }

  return { register, listPublic };
};
